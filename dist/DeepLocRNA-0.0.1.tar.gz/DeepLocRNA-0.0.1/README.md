# DeepLocRNA
This is the counterpart of DeepLoc, but in RNA level
